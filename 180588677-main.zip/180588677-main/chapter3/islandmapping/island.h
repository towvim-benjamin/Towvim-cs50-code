//DO NOT CHANGE ANYTHING IN THIS FILE



#include<cs50.h>

int mapping(int island[5][5]);
