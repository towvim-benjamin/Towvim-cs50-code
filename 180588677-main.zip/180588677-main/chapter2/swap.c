#include <stdio.h>
#include <cs50.h>
int swap(int a, int b);
int main(void){
    int num;
    int num2;
    do{
        num = get_int("enter any number: \n);
        num2 = get_int("enter any number: \n);
    }
    while(num1 == num2)
    

}
int swap(int a, int b){
    int c = b;
    b=a;
    a=b;
    return a,b;
}
