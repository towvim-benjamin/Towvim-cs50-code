#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    int a = 2;
    int b = 32;
    int result = pow(a, b);
    printf("result: %i\n" , result);
}
